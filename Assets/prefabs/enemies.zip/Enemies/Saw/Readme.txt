Sprites are from the kenney.nl Platformer Pack Redux
Download from http://kenney.nl/assets/platformer-pack-redux

INSCRUCTIONS
simply drag and drop the prefab onto your scene. Configure the AI from the script attached to the brain gameobject.

1. ****IMPORTANT****the ground tiles MUST have a layer or Ground on layer 9. This is how it knows when to stop on edges that are not empty space and stop when casing a player. (the layer can be changed in the script under the maskLayer variable)

2. Drag the prefab onto the scene or instantiate it
